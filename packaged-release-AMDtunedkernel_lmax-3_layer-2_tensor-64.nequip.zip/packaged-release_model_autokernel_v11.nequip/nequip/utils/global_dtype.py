import torch

# singular source of global dtype that dictates the dtype of the data, which is always float64
_GLOBAL_DTYPE = torch.float64
