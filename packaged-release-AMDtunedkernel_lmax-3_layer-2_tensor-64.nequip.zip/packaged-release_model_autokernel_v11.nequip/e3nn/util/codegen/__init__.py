from ._mixin import CodeGenMixin


__all__ = [
    "CodeGenMixin",
]
